﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace DBFirst_PMA
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ProductContext context = new ProductContext();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int ProId = int.Parse(productId.Text);
            string ProName = productName.Text;
            int ProPrice = int.Parse(productPrice.Text);
            int ProQuantity = int.Parse(productQuantity.Text);
            Products_dsingh58 product = new Products_dsingh58()
            {
                id = ProId,
                name = ProName,
                price = ProPrice,
                quantity = ProQuantity
            };
            context.Products_dsingh58.Add(product);
            context.SaveChanges();
            Display();
            MessageBox.Show("Added successfully!!");
            //context.Products_dsingh58.Add()
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Display();
        }
        public void Display()
        {
            productDetails.DataContext = context.Products_dsingh58.ToList();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            int ProId = int.Parse(search.Text);
           Products_dsingh58 searchProduct= context.Products_dsingh58.ToList().Find(product => product.id == ProId);
            if (searchProduct != null) { 
            productId.Text =searchProduct.id.ToString();
            productName.Text = searchProduct.name;
            productPrice.Text = searchProduct.price.ToString();
            productQuantity.Text = searchProduct.quantity.ToString();

            }
            else
            {
                MessageBox.Show("Product Not Found!!");
            }

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            int SearchProId = int.Parse(search.Text);
            Products_dsingh58 searchProduct = context.Products_dsingh58.ToList().Find(product => product.id == SearchProId);
            if (searchProduct != null)
            {
                int ProId = int.Parse(productId.Text);
                string ProName = productName.Text;
                int ProPrice = int.Parse(productPrice.Text);
                int ProQuantity = int.Parse(productQuantity.Text);

                searchProduct.id = ProId;
                searchProduct.name = ProName;
                searchProduct.price = ProPrice;
                searchProduct.quantity = ProQuantity;
                context.SaveChanges();
                Display();
                MessageBox.Show("Product updated successfully!!");
            }
            else
            {
                MessageBox.Show("Product Not Found!!");
            }
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            int SearchProId = int.Parse(search.Text);
            Products_dsingh58 searchProduct = context.Products_dsingh58.ToList().Find(product => product.id == SearchProId);
            if (searchProduct != null)
            {
                context.Products_dsingh58.Remove(searchProduct);
                context.SaveChanges();
                Display();
                MessageBox.Show("Product Deleted Successfully!!");
                
            }
            else
            {
                MessageBox.Show("Product Not Found!!");
            }

            }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            List<Products_dsingh58> products=context.Products_dsingh58.ToList().FindAll(product => product.price > 50);
            productDetails.DataContext = products;
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            string proName = search.Text;
            // alphabet contain anywhere
            // List<Products_dsingh58> products = context.Products_dsingh58.ToList().Where(product => product.name.Contains(proName)).ToList();
            // alphabet contain start
            // List<Products_dsingh58> products = context.Products_dsingh58.ToList().Where(product => product.name.StartsWith(proName)).ToList();
            // List<Products_dsingh58> products = context.Products_dsingh58.ToList().Where(product => product.name.EndsWith(proName)).ToList();
            List<Products_dsingh58> products = context.Products_dsingh58.ToList().Where(product => product.name.Equals(proName)).ToList();
         //  Products_dsingh58  products = context.Products_dsingh58.ToList().Find(product => product.name.Equals(proName));
           

           
           productDetails.DataContext=products[0].name;
        }
    }
}
