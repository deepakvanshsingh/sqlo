﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace ProductManagementDisconnected
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
      
        SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["conString"].ConnectionString);
        DataSet dataSet = new DataSet();
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter adapter=null;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DataRow newRow = dataSet.Tables[0].NewRow();
            newRow[0] = productId.Text;
            newRow[1] = productName.Text;
            newRow[2] = productPrice.Text;
            newRow[3] = productQuantity.Text;
            dataSet.Tables[0].Rows.Add(newRow);
            MessageBox.Show("Record Added Successfully!!");
        }
        public void Display()
        {
            cmd.CommandText = "select * from Products_dsingh58";
            cmd.Connection = connection;
            adapter = new SqlDataAdapter(cmd.CommandText, connection);

            adapter.Fill(dataSet);
            productDetails.DataContext = dataSet.Tables[0];
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Display();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(adapter);
            adapter.Update(dataSet);
            adapter.UpdateCommand = sqlCommandBuilder.GetUpdateCommand();
            MessageBox.Show("All changes written to database");

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            int SearchProductid = int.Parse(search.Text);
            for (int i = 0; i<int.Parse(dataSet.Tables[0].Rows[i][0].ToString());i++)
            {
                int currentProductId = int.Parse(dataSet.Tables[0].Rows[i][0].ToString());
                if (currentProductId == int.Parse(search.Text))
                {
                    productId.Text = dataSet.Tables[0].Rows[i][0].ToString();
                    productName.Text = dataSet.Tables[0].Rows[i][1].ToString();
                    productPrice.Text = dataSet.Tables[0].Rows[i][2].ToString();
                    productQuantity.Text = dataSet.Tables[0].Rows[i][3].ToString();
                    break;
                }
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            int SearchProductid = int.Parse(search.Text);
            for (int i = 0; i < int.Parse(dataSet.Tables[0].Rows[i][0].ToString()); i++)
            {
                int currentProductId = int.Parse(dataSet.Tables[0].Rows[i][0].ToString());
                if (currentProductId == int.Parse(search.Text))
                {
                    dataSet.Tables[0].Rows[i][0] = productId.Text;
                    dataSet.Tables[0].Rows[i][1] = productName.Text;
                    dataSet.Tables[0].Rows[i][2] = productPrice.Text;
                    dataSet.Tables[0].Rows[i][3] = productQuantity.Text;
                    break;
                }
            }

        }
    }
}
